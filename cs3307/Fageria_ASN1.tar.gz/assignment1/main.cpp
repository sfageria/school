
/* -------------------
SHUBH FAGERIA
FEBRUARY 7, 2023
CS3307
Assignment 1
--------------------*/

#include "gameObject.h"
#include "request.h"
int main(void)
{
  initRequest();
  return 0;
}

